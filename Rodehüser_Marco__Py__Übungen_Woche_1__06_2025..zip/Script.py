f = open("C:\BckUp\Python\test.txt")

print(f.read())

