#f = open("myfile.txt", "x")


# f = open("myfile.txt")
# print(f.read())


# with open("myfile.txt", "a") as f:
#   f.write("Now the file has more content!")

f = open("C:\BckUp\Python\myfile.txt")
print(f.read())
